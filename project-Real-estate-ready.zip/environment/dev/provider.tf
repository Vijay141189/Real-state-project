terraform {
    required_providers {
        azurerm = {
            source  = "hashicorp/azurerm"
            version = "4.81.0"
        }
        random = {
            source  = "hashicorp/random"
            version = "~> 3.6"
        }
    }

    backend "azurerm" {
        resource_group_name  = "tfstate-rg"
        storage_account_name = "tfstatelz1411"
        container_name        = "tfstate"
        key                    = "dev.terraform.tfstate"
    }
}

provider "azurerm" {
    features {}
    resource_provider_registrations = "none"
}